//------------------------------------------------------------------------------
//  UsingRedisService.cpp
//  (C) 2016 n.lee
//------------------------------------------------------------------------------
#include "UsingRedisService.h"

#ifdef _MSC_VER
	#ifdef _DEBUG
		#define new   new(_NORMAL_BLOCK, __FILE__,__LINE__)
	#endif
#endif

namespace O2 {
	extern "C" {

	}
}