#pragma once
//------------------------------------------------------------------------------
/**
    @class CUsingRedisService
    
    (C) 2016 n.lee
*/
#ifdef _MSC_VER
	#pragma warning(disable:4251)
	#pragma warning(disable:4250)
#endif

#include "RedisService.h"

/*EOF*/